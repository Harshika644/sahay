import streamlit as st
import random

st.set_page_config(page_title="Relief Chatbot", layout="centered")

st.title("🤖 Relief Support Chatbot")
st.markdown("This chatbot is designed to support survivors of natural calamities.")

user_input = st.text_input("You: ", "")

responses = {
    "hello": "Hi there! How can I help you today?",
    "food": "We have food supply centers near your area. Please visit your nearest relief camp.",
    "shelter": "Temporary shelters are available at local schools and community centers.",
    "medical": "Medical teams are on their way. You can visit the mobile clinic set up in your locality.",
    "thank you": "You're welcome! Stay safe.",
}

def get_response(message):
    for key in responses:
        if key in message.lower():
            return responses[key]
    return "I'm here to help. Please provide more details."

if user_input:
    bot_response = get_response(user_input)
    st.text_area("Bot:", value=bot_response, height=100, max_chars=None, key=None)