
import streamlit as st
import joblib
import numpy as np

st.set_page_config(page_title="Flood Risk Predictor", layout="centered")
st.title("🌧️ Flood Risk Predictor")
st.markdown("Enter the environmental values below to predict if there's a flood risk.")

# User Inputs
rainfall = st.number_input("Rainfall (mm)", min_value=0.0, value=180.0)
river_level = st.number_input("River Level (m)", min_value=0.0, value=4.5)
soil_moisture = st.slider("Soil Moisture (0.0 - 1.0)", 0.0, 1.0, 0.5)
elevation = st.number_input("Elevation (m)", min_value=0.0, value=300.0)

if st.button("Predict Flood Risk"):
    model = joblib.load("model/flood_model.pkl")
    features = np.array([[rainfall, river_level, soil_moisture, elevation]])
    prediction = model.predict(features)[0]
    prob = model.predict_proba(features)[0][1]

    if prediction == 1:
        st.error(f"⚠️ High Flood Risk! (Confidence: {prob:.2%})")
    else:
        st.success(f"✅ Low Flood Risk (Confidence: {prob:.2%})")
